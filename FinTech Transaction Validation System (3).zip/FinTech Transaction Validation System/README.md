
  # FinTech Transaction Validation System

  This is a code bundle for FinTech Transaction Validation System.  

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  