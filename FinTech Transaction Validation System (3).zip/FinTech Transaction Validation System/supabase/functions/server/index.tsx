import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Transaction limits configuration
const TRANSACTION_LIMITS = {
  MIN_AMOUNT: 0.01,
  MAX_AMOUNT: 10000,
  DAILY_LIMIT: 25000,
  MAX_TRANSACTIONS_PER_DAY: 50,
};

// Helper function to generate transaction ID
function generateTransactionId(): string {
  return `TXN${Date.now()}${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
}

// Helper function to validate transaction data
function validateTransactionInput(data: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Validate sender account
  if (!data.senderAccount || typeof data.senderAccount !== 'string' || data.senderAccount.trim().length === 0) {
    errors.push('Sender account is required');
  } else if (!/^[A-Z0-9]{10,20}$/.test(data.senderAccount.trim())) {
    errors.push('Sender account must be 10-20 alphanumeric characters');
  }

  // Validate recipient account
  if (!data.recipientAccount || typeof data.recipientAccount !== 'string' || data.recipientAccount.trim().length === 0) {
    errors.push('Recipient account is required');
  } else if (!/^[A-Z0-9]{10,20}$/.test(data.recipientAccount.trim())) {
    errors.push('Recipient account must be 10-20 alphanumeric characters');
  }

  // Check if sender and recipient are the same
  if (data.senderAccount && data.recipientAccount && data.senderAccount.trim() === data.recipientAccount.trim()) {
    errors.push('Sender and recipient accounts cannot be the same');
  }

  // Validate amount
  if (!data.amount || isNaN(parseFloat(data.amount))) {
    errors.push('Valid amount is required');
  } else {
    const amount = parseFloat(data.amount);
    if (amount < TRANSACTION_LIMITS.MIN_AMOUNT) {
      errors.push(`Amount must be at least $${TRANSACTION_LIMITS.MIN_AMOUNT}`);
    }
    if (amount > TRANSACTION_LIMITS.MAX_AMOUNT) {
      errors.push(`Amount cannot exceed $${TRANSACTION_LIMITS.MAX_AMOUNT}`);
    }
  }

  // Validate currency
  if (!data.currency || typeof data.currency !== 'string') {
    errors.push('Currency is required');
  } else if (!['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD'].includes(data.currency.toUpperCase())) {
    errors.push('Invalid currency. Supported: USD, EUR, GBP, JPY, CAD, AUD');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Helper function to check daily limits
async function checkDailyLimits(senderAccount: string, amount: number): Promise<{ withinLimit: boolean; message?: string; currentAmount?: number; transactionCount?: number }> {
  const today = new Date().toISOString().split('T')[0];
  const dailyKey = `daily:${senderAccount}:${today}`;
  
  try {
    const dailyData = await kv.get(dailyKey);
    
    if (dailyData) {
      const { totalAmount, count } = dailyData as { totalAmount: number; count: number };
      
      // Check transaction count limit
      if (count >= TRANSACTION_LIMITS.MAX_TRANSACTIONS_PER_DAY) {
        return {
          withinLimit: false,
          message: `Daily transaction limit reached (${TRANSACTION_LIMITS.MAX_TRANSACTIONS_PER_DAY} transactions)`,
          currentAmount: totalAmount,
          transactionCount: count,
        };
      }
      
      // Check amount limit
      if (totalAmount + amount > TRANSACTION_LIMITS.DAILY_LIMIT) {
        return {
          withinLimit: false,
          message: `Daily amount limit would be exceeded. Current: $${totalAmount.toFixed(2)}, Limit: $${TRANSACTION_LIMITS.DAILY_LIMIT}`,
          currentAmount: totalAmount,
          transactionCount: count,
        };
      }
      
      return {
        withinLimit: true,
        currentAmount: totalAmount,
        transactionCount: count,
      };
    }
    
    // First transaction of the day
    return {
      withinLimit: true,
      currentAmount: 0,
      transactionCount: 0,
    };
  } catch (error) {
    console.error(`Error checking daily limits for ${senderAccount}: ${error}`);
    throw error;
  }
}

// Helper function to update daily limits
async function updateDailyLimits(senderAccount: string, amount: number): Promise<void> {
  const today = new Date().toISOString().split('T')[0];
  const dailyKey = `daily:${senderAccount}:${today}`;
  
  try {
    const dailyData = await kv.get(dailyKey);
    
    if (dailyData) {
      const { totalAmount, count } = dailyData as { totalAmount: number; count: number };
      await kv.set(dailyKey, {
        totalAmount: totalAmount + amount,
        count: count + 1,
      });
    } else {
      await kv.set(dailyKey, {
        totalAmount: amount,
        count: 1,
      });
    }
  } catch (error) {
    console.error(`Error updating daily limits for ${senderAccount}: ${error}`);
    throw error;
  }
}

// Health check endpoint
app.get("/make-server-f5b9b458/health", (c) => {
  return c.json({ status: "ok" });
});

// Get transaction limits
app.get("/make-server-f5b9b458/transaction-limits", (c) => {
  return c.json({
    success: true,
    limits: TRANSACTION_LIMITS,
  });
});

// Submit and validate transaction
app.post("/make-server-f5b9b458/transactions", async (c) => {
  try {
    const data = await c.req.json();
    
    // Step 1: Input validation
    const validation = validateTransactionInput(data);
    if (!validation.valid) {
      return c.json({
        success: false,
        status: 'VALIDATION_FAILED',
        errors: validation.errors,
      }, 400);
    }

    const amount = parseFloat(data.amount);
    const senderAccount = data.senderAccount.trim();
    const recipientAccount = data.recipientAccount.trim();
    const currency = data.currency.toUpperCase();

    // Step 2: Check daily limits
    const limitCheck = await checkDailyLimits(senderAccount, amount);
    if (!limitCheck.withinLimit) {
      return c.json({
        success: false,
        status: 'LIMIT_EXCEEDED',
        message: limitCheck.message,
        dailyStats: {
          currentAmount: limitCheck.currentAmount,
          transactionCount: limitCheck.transactionCount,
          dailyLimit: TRANSACTION_LIMITS.DAILY_LIMIT,
          maxTransactions: TRANSACTION_LIMITS.MAX_TRANSACTIONS_PER_DAY,
        },
      }, 400);
    }

    // Step 3: Process transaction
    const transactionId = generateTransactionId();
    const timestamp = new Date().toISOString();
    
    const transaction = {
      transactionId,
      senderAccount,
      recipientAccount,
      amount,
      currency,
      status: 'APPROVED',
      timestamp,
      description: data.description || '',
    };

    // Save transaction to KV store
    await kv.set(`transaction:${transactionId}`, transaction);
    
    // Update daily limits
    await updateDailyLimits(senderAccount, amount);

    // Also save to sender's transaction history
    const senderHistoryKey = `history:${senderAccount}:${transactionId}`;
    await kv.set(senderHistoryKey, {
      transactionId,
      timestamp,
      type: 'DEBIT',
      amount,
      currency,
      counterparty: recipientAccount,
    });

    // Save to recipient's transaction history
    const recipientHistoryKey = `history:${recipientAccount}:${transactionId}`;
    await kv.set(recipientHistoryKey, {
      transactionId,
      timestamp,
      type: 'CREDIT',
      amount,
      currency,
      counterparty: senderAccount,
    });

    return c.json({
      success: true,
      status: 'APPROVED',
      transaction,
      message: 'Transaction processed successfully',
    }, 201);

  } catch (error) {
    console.error(`Error processing transaction: ${error}`);
    return c.json({
      success: false,
      status: 'SYSTEM_ERROR',
      message: 'An error occurred while processing the transaction',
      error: String(error),
    }, 500);
  }
});

// Get transaction by ID
app.get("/make-server-f5b9b458/transactions/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const transaction = await kv.get(`transaction:${id}`);
    
    if (!transaction) {
      return c.json({
        success: false,
        message: 'Transaction not found',
      }, 404);
    }

    return c.json({
      success: true,
      transaction,
    });
  } catch (error) {
    console.error(`Error retrieving transaction: ${error}`);
    return c.json({
      success: false,
      message: 'Error retrieving transaction',
      error: String(error),
    }, 500);
  }
});

// Get account transaction history
app.get("/make-server-f5b9b458/accounts/:accountId/history", async (c) => {
  try {
    const accountId = c.req.param('accountId');
    const prefix = `history:${accountId}:`;
    
    const historyItems = await kv.getByPrefix(prefix);
    
    // Sort by timestamp descending
    const sortedHistory = historyItems.sort((a: any, b: any) => {
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });

    return c.json({
      success: true,
      account: accountId,
      transactions: sortedHistory,
      count: sortedHistory.length,
    });
  } catch (error) {
    console.error(`Error retrieving account history: ${error}`);
    return c.json({
      success: false,
      message: 'Error retrieving account history',
      error: String(error),
    }, 500);
  }
});

// Get daily statistics for an account
app.get("/make-server-f5b9b458/accounts/:accountId/daily-stats", async (c) => {
  try {
    const accountId = c.req.param('accountId');
    const today = new Date().toISOString().split('T')[0];
    const dailyKey = `daily:${accountId}:${today}`;
    
    const dailyData = await kv.get(dailyKey);
    
    if (!dailyData) {
      return c.json({
        success: true,
        account: accountId,
        date: today,
        stats: {
          totalAmount: 0,
          transactionCount: 0,
          remainingAmount: TRANSACTION_LIMITS.DAILY_LIMIT,
          remainingTransactions: TRANSACTION_LIMITS.MAX_TRANSACTIONS_PER_DAY,
        },
      });
    }

    const { totalAmount, count } = dailyData as { totalAmount: number; count: number };

    return c.json({
      success: true,
      account: accountId,
      date: today,
      stats: {
        totalAmount,
        transactionCount: count,
        remainingAmount: TRANSACTION_LIMITS.DAILY_LIMIT - totalAmount,
        remainingTransactions: TRANSACTION_LIMITS.MAX_TRANSACTIONS_PER_DAY - count,
      },
    });
  } catch (error) {
    console.error(`Error retrieving daily stats: ${error}`);
    return c.json({
      success: false,
      message: 'Error retrieving daily statistics',
      error: String(error),
    }, 500);
  }
});

Deno.serve(app.fetch);