import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { CheckCircle2 } from "lucide-react";

interface Transaction {
  transactionId: string;
  senderAccount: string;
  recipientAccount: string;
  amount: number;
  currency: string;
  status: string;
  timestamp: string;
  description?: string;
}

interface RecentTransactionsProps {
  transactions: Transaction[];
}

export function RecentTransactions({ transactions }: RecentTransactionsProps) {
  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
        <CardDescription>
          Successfully processed transactions in this session
        </CardDescription>
      </CardHeader>
      <CardContent>
        {transactions.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No transactions yet</p>
            <p className="text-sm mt-1">
              Submit a transaction to see it appear here
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {transactions.map((transaction) => (
              <div
                key={transaction.transactionId}
                className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="size-5 text-green-600" />
                    <div>
                      <p className="font-semibold">
                        {transaction.currency} {transaction.amount.toFixed(2)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(transaction.timestamp)}
                      </p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                    {transaction.status}
                  </Badge>
                </div>

                <div className="space-y-1 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground w-16">From:</span>
                    <span className="font-mono">{transaction.senderAccount}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground w-16">To:</span>
                    <span className="font-mono">{transaction.recipientAccount}</span>
                  </div>
                  {transaction.description && (
                    <div className="flex items-start gap-2">
                      <span className="text-muted-foreground w-16">Note:</span>
                      <span className="flex-1 text-muted-foreground italic">
                        {transaction.description}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 pt-2 border-t mt-2">
                    <span className="text-muted-foreground w-16">ID:</span>
                    <span className="font-mono text-xs text-muted-foreground">
                      {transaction.transactionId}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
