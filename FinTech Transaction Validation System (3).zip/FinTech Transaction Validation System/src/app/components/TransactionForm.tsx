import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { AlertCircle, CheckCircle2, XCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";

interface TransactionFormProps {
  onTransactionSubmit: (transaction: any) => void;
  transactionLimits: any;
}

export function TransactionForm({ onTransactionSubmit, transactionLimits }: TransactionFormProps) {
  const [formData, setFormData] = useState({
    senderAccount: "",
    recipientAccount: "",
    amount: "",
    currency: "USD",
    description: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [transactionResult, setTransactionResult] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setValidationErrors([]);
    setTransactionResult(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-f5b9b458/transactions`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const result = await response.json();

      if (result.success) {
        setTransactionResult(result);
        onTransactionSubmit(result.transaction);
        // Reset form
        setFormData({
          senderAccount: "",
          recipientAccount: "",
          amount: "",
          currency: "USD",
          description: "",
        });
      } else {
        setValidationErrors(result.errors || [result.message]);
        setTransactionResult(result);
      }
    } catch (error) {
      console.error("Error submitting transaction:", error);
      setValidationErrors(["Failed to connect to server. Please try again."]);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setValidationErrors([]);
    setTransactionResult(null);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>New Transaction</CardTitle>
        <CardDescription>
          Enter transaction details to process a secure payment
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="senderAccount">Sender Account</Label>
            <Input
              id="senderAccount"
              placeholder="e.g., ACC1234567890"
              value={formData.senderAccount}
              onChange={(e) => handleInputChange("senderAccount", e.target.value.toUpperCase())}
              required
              disabled={isSubmitting}
            />
            <p className="text-sm text-muted-foreground">
              10-20 alphanumeric characters
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="recipientAccount">Recipient Account</Label>
            <Input
              id="recipientAccount"
              placeholder="e.g., ACC9876543210"
              value={formData.recipientAccount}
              onChange={(e) => handleInputChange("recipientAccount", e.target.value.toUpperCase())}
              required
              disabled={isSubmitting}
            />
            <p className="text-sm text-muted-foreground">
              10-20 alphanumeric characters
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min={transactionLimits?.MIN_AMOUNT || 0.01}
                max={transactionLimits?.MAX_AMOUNT || 10000}
                placeholder="0.00"
                value={formData.amount}
                onChange={(e) => handleInputChange("amount", e.target.value)}
                required
                disabled={isSubmitting}
              />
              <p className="text-sm text-muted-foreground">
                ${transactionLimits?.MIN_AMOUNT || 0.01} - ${transactionLimits?.MAX_AMOUNT?.toLocaleString() || "10,000"}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select
                value={formData.currency}
                onValueChange={(value) => handleInputChange("currency", value)}
                disabled={isSubmitting}
              >
                <SelectTrigger id="currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD - US Dollar</SelectItem>
                  <SelectItem value="EUR">EUR - Euro</SelectItem>
                  <SelectItem value="GBP">GBP - British Pound</SelectItem>
                  <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                  <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
                  <SelectItem value="AUD">AUD - Australian Dollar</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              placeholder="Payment for invoice #123..."
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              disabled={isSubmitting}
              rows={3}
            />
          </div>

          {validationErrors.length > 0 && (
            <Alert variant="destructive">
              <XCircle className="size-4" />
              <AlertTitle>Validation Failed</AlertTitle>
              <AlertDescription>
                <ul className="list-disc pl-4 space-y-1">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {transactionResult && transactionResult.status === "LIMIT_EXCEEDED" && (
            <Alert variant="destructive">
              <AlertCircle className="size-4" />
              <AlertTitle>Daily Limit Exceeded</AlertTitle>
              <AlertDescription>
                <p className="mb-2">{transactionResult.message}</p>
                {transactionResult.dailyStats && (
                  <div className="text-sm space-y-1">
                    <p>
                      Today's total: ${transactionResult.dailyStats.currentAmount?.toFixed(2)} / 
                      ${transactionResult.dailyStats.dailyLimit?.toLocaleString()}
                    </p>
                    <p>
                      Transactions: {transactionResult.dailyStats.transactionCount} / 
                      {transactionResult.dailyStats.maxTransactions}
                    </p>
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}

          {transactionResult && transactionResult.status === "APPROVED" && (
            <Alert className="border-green-500 bg-green-50 text-green-900">
              <CheckCircle2 className="size-4 text-green-600" />
              <AlertTitle>Transaction Approved</AlertTitle>
              <AlertDescription>
                <p className="mb-2">{transactionResult.message}</p>
                <p className="text-sm">
                  Transaction ID: <span className="font-mono font-semibold">{transactionResult.transaction?.transactionId}</span>
                </p>
              </AlertDescription>
            </Alert>
          )}

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Processing..." : "Submit Transaction"}
          </Button>
        </form>

        {transactionLimits && (
          <div className="mt-6 pt-6 border-t">
            <h4 className="font-semibold mb-3">Transaction Limits</h4>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-muted-foreground">Per Transaction</p>
                <p className="font-semibold">
                  ${transactionLimits.MIN_AMOUNT} - ${transactionLimits.MAX_AMOUNT?.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Daily Limit</p>
                <p className="font-semibold">${transactionLimits.DAILY_LIMIT?.toLocaleString()}</p>
              </div>
              <div className="col-span-2">
                <p className="text-muted-foreground">Max Transactions/Day</p>
                <p className="font-semibold">{transactionLimits.MAX_TRANSACTIONS_PER_DAY}</p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}