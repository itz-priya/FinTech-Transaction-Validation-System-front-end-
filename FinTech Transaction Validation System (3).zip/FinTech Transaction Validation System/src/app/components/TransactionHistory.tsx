import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Button } from "./ui/button";
import { ArrowDownCircle, ArrowUpCircle, Search, RefreshCw } from "lucide-react";
import { Alert, AlertDescription } from "./ui/alert";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";

interface Transaction {
  transactionId: string;
  timestamp: string;
  type: "DEBIT" | "CREDIT";
  amount: number;
  currency: string;
  counterparty: string;
}

export function TransactionHistory() {
  const [accountId, setAccountId] = useState("");
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [dailyStats, setDailyStats] = useState<any>(null);

  const fetchHistory = async () => {
    if (!accountId.trim()) {
      setError("Please enter an account ID");
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-f5b9b458/accounts/${accountId.trim()}/history`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();

      if (result.success) {
        setTransactions(result.transactions || []);
        fetchDailyStats();
      } else {
        setError(result.message || "Failed to fetch transaction history");
      }
    } catch (err) {
      console.error("Error fetching history:", err);
      setError("Failed to connect to server");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchDailyStats = async () => {
    if (!accountId.trim()) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-f5b9b458/accounts/${accountId.trim()}/daily-stats`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();

      if (result.success) {
        setDailyStats(result.stats);
      }
    } catch (err) {
      console.error("Error fetching daily stats:", err);
    }
  };

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      fetchHistory();
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Transaction History</CardTitle>
        <CardDescription>
          View transaction history for any account
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1 space-y-2">
            <Label htmlFor="searchAccount">Account ID</Label>
            <Input
              id="searchAccount"
              placeholder="e.g., ACC1234567890"
              value={accountId}
              onChange={(e) => setAccountId(e.target.value.toUpperCase())}
              onKeyPress={handleKeyPress}
              disabled={isLoading}
            />
          </div>
          <div className="flex items-end gap-2">
            <Button onClick={fetchHistory} disabled={isLoading || !accountId.trim()}>
              {isLoading ? (
                <>
                  <RefreshCw className="size-4 mr-2 animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <Search className="size-4 mr-2" />
                  Search
                </>
              )}
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {dailyStats && (
          <div className="p-4 bg-muted rounded-lg">
            <h4 className="font-semibold mb-3">Today's Activity</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Total Spent</p>
                <p className="text-lg font-semibold">
                  ${dailyStats.totalAmount?.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Remaining Limit</p>
                <p className="text-lg font-semibold">
                  ${dailyStats.remainingAmount?.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Transactions</p>
                <p className="text-lg font-semibold">
                  {dailyStats.transactionCount} / {dailyStats.transactionCount + dailyStats.remainingTransactions}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Remaining</p>
                <p className="text-lg font-semibold">
                  {dailyStats.remainingTransactions} left
                </p>
              </div>
            </div>
          </div>
        )}

        {transactions.length > 0 ? (
          <div className="space-y-2">
            <h4 className="font-semibold">
              Transactions ({transactions.length})
            </h4>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {transactions.map((transaction) => (
                <div
                  key={transaction.transactionId}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {transaction.type === "DEBIT" ? (
                      <ArrowUpCircle className="size-5 text-red-500" />
                    ) : (
                      <ArrowDownCircle className="size-5 text-green-500" />
                    )}
                    <div>
                      <p className="font-medium">
                        {transaction.type === "DEBIT" ? "Sent to" : "Received from"}{" "}
                        {transaction.counterparty}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(transaction.timestamp)}
                      </p>
                      <p className="text-xs text-muted-foreground font-mono">
                        {transaction.transactionId}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`font-semibold ${
                        transaction.type === "DEBIT"
                          ? "text-red-600"
                          : "text-green-600"
                      }`}
                    >
                      {transaction.type === "DEBIT" ? "-" : "+"}
                      {transaction.currency} {transaction.amount.toFixed(2)}
                    </p>
                    <Badge
                      variant={
                        transaction.type === "DEBIT" ? "destructive" : "default"
                      }
                      className="mt-1"
                    >
                      {transaction.type}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          !isLoading &&
          accountId && (
            <div className="text-center py-8 text-muted-foreground">
              <p>No transactions found for this account</p>
            </div>
          )
        )}
      </CardContent>
    </Card>
  );
}