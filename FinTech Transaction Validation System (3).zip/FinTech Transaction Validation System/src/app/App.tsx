import { useState, useEffect } from "react";
import { TransactionForm } from "./components/TransactionForm";
import { TransactionHistory } from "./components/TransactionHistory";
import { RecentTransactions } from "./components/RecentTransactions";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { DollarSign, Shield, Activity } from "lucide-react";
import { projectId, publicAnonKey } from "../../utils/supabase/info";

export default function App() {
  const [recentTransactions, setRecentTransactions] = useState<any[]>([]);
  const [transactionLimits, setTransactionLimits] = useState<any>(null);

  useEffect(() => {
    fetchTransactionLimits();
  }, []);

  const fetchTransactionLimits = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-f5b9b458/transaction-limits`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      const result = await response.json();
      if (result.success) {
        setTransactionLimits(result.limits);
      }
    } catch (error) {
      console.error("Error fetching transaction limits:", error);
    }
  };

  const handleTransactionSubmit = (transaction: any) => {
    setRecentTransactions((prev) => [transaction, ...prev]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Shield className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl tracking-tight">
                FinTech Transaction Validation System
              </h1>
              <p className="text-muted-foreground">
                Secure digital financial transaction processing with real-time validation
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="new-transaction" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="new-transaction" className="flex items-center gap-2">
              <DollarSign className="size-4" />
              <span className="hidden sm:inline">New Transaction</span>
              <span className="sm:hidden">New</span>
            </TabsTrigger>
            <TabsTrigger value="recent" className="flex items-center gap-2">
              <Activity className="size-4" />
              <span className="hidden sm:inline">Recent</span>
              <span className="sm:hidden">Recent</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <Activity className="size-4" />
              <span className="hidden sm:inline">History</span>
              <span className="sm:hidden">History</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="new-transaction">
            <div className="grid lg:grid-cols-2 gap-6">
              <TransactionForm
                onTransactionSubmit={handleTransactionSubmit}
                transactionLimits={transactionLimits}
              />
              <RecentTransactions transactions={recentTransactions} />
            </div>
          </TabsContent>

          <TabsContent value="recent">
            <RecentTransactions transactions={recentTransactions} />
          </TabsContent>

          <TabsContent value="history">
            <TransactionHistory />
          </TabsContent>
        </Tabs>

        {/* Features Info */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-lg border">
            <div className="p-2 bg-blue-100 rounded-lg w-fit mb-3">
              <Shield className="size-5 text-blue-600" />
            </div>
            <h3 className="font-semibold mb-2">Secure Validation</h3>
            <p className="text-sm text-muted-foreground">
              Multi-layer validation ensures all transaction data meets security and format requirements
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg border">
            <div className="p-2 bg-green-100 rounded-lg w-fit mb-3">
              <DollarSign className="size-5 text-green-600" />
            </div>
            <h3 className="font-semibold mb-2">Limit Enforcement</h3>
            <p className="text-sm text-muted-foreground">
              Automatic daily limits protect against excessive transactions and amounts
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg border">
            <div className="p-2 bg-purple-100 rounded-lg w-fit mb-3">
              <Activity className="size-5 text-purple-600" />
            </div>
            <h3 className="font-semibold mb-2">Real-time Status</h3>
            <p className="text-sm text-muted-foreground">
              Instant transaction processing with immediate approval or rejection feedback
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}